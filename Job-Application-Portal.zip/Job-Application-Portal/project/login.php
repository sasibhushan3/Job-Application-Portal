<!DOCTYPE html>
<html>
<body>

<!-- <button type="button">Login</button>
<button type="button">Signup</button> -->
<br><br>
	<center>
		<h3>Login</h3>
		<form action = "loginbackend.php" method = "POST">
			<input name = "username" placeholder = "username"><br><br>
			<input name = "password" type = "password" placeholder = "Password"><br><br>
			<button type = "submit">Submit</button>
		</form>
	</center>
</body>
</html>
