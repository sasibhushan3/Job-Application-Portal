<?php
$host = "localhost";
$user = "sasi";
$dbpass = "mypass";
$dbname = "dbms";
$con = mysqli_connect($host,$user,$dbpass,$dbname);
?>
