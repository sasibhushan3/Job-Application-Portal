<html>
<body>
<?php
	// session_start();
	// $username = $_SESSION['username'];
	// $_SESSION['username']=$username;
	// echo "$username";

?>
	<br><br>
	<center>
		<h3>Inserted Successfully</h3>
		<a href = "emphome.php">Home</a><br><br>
	</center>
</body>
</html>